-- Create both databases if they don’t exist
CREATE DATABASE IF NOT EXISTS products_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS products_test_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- ========================================
-- Init for products_db
-- ========================================
USE products_db;

CREATE TABLE IF NOT EXISTS tblplLanguage (
    LanguageID INT AUTO_INCREMENT PRIMARY KEY,
    LanguageCode VARCHAR(50) NOT NULL
);

INSERT IGNORE INTO tblplLanguage (LanguageCode) VALUES
  ('de'), ('en'), ('es'), ('fr'), ('it');

CREATE TABLE IF NOT EXISTS tblProduct (
    ProductGtin VARCHAR(14) PRIMARY KEY,
    ProductLanguageID INT NOT NULL,
    ProductTitle VARCHAR(255) NOT NULL,
    ProductPictureURL VARCHAR(500),
    ProductDescription TEXT,
    ProductPrice DECIMAL(10,2) NOT NULL,
    ProductStock INT NOT NULL,
    FOREIGN KEY (ProductLanguageID) REFERENCES tblplLanguage(LanguageID)
    );

-- ========================================
-- Init for products_test_db (same schema)
-- ========================================
USE products_test_db;

CREATE TABLE IF NOT EXISTS tblplLanguage (
     LanguageID INT AUTO_INCREMENT PRIMARY KEY,
     LanguageCode VARCHAR(50) NOT NULL
);

INSERT IGNORE INTO tblplLanguage (LanguageCode) VALUES
  ('de'), ('en'), ('es'), ('fr'), ('it');

CREATE TABLE IF NOT EXISTS tblProduct (
    ProductGtin VARCHAR(14) PRIMARY KEY,
    ProductLanguageID INT NOT NULL,
    ProductTitle VARCHAR(255) NOT NULL,
    ProductPictureURL VARCHAR(500),
    ProductDescription TEXT,
    ProductPrice DECIMAL(10,2) NOT NULL,
    ProductStock INT NOT NULL,
    FOREIGN KEY (ProductLanguageID) REFERENCES tblplLanguage(LanguageID)
    );
