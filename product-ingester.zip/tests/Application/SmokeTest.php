<?php

namespace Tests\Application;

use PHPUnit\Framework\TestCase;

class SmokeTest extends TestCase
{
    public function testSomethingWorks(): void
    {
        $this->assertTrue(true);
    }
}
