<?php

namespace Tests\Application\Ingester;

use App\Application\Ingester\CsvIngester;
use App\Domain\Repository\ProductRepositoryInterface;
use App\Domain\Service\ValidationService;
use App\Infrastructure\Logger\LoggerInterface;
use PHPUnit\Framework\TestCase;

class CsvIngesterTest extends TestCase {
    public function testCsvIngesterProcessesValidRow(): void {
        $mockRepo = $this->createMock(ProductRepositoryInterface::class);
        $mockValidator = $this->createMock(ValidationService::class);
        $mockLogger = $this->createMock(LoggerInterface::class);

        $mockValidator->method('validate')->willReturn(true);
        $mockRepo->expects($this->once())->method('saveProduct');

        $csvFile = tempnam(sys_get_temp_dir(), 'csv');
        file_put_contents($csvFile, <<<CSV
gtin,language,title,picture,description,price,stock
1234567890123,en,Test Product,https://example.com/pic.jpg,desc,19.99,100
CSV);

        // anonymous class to override getCsvFilePath()
        $ingester = new class($mockRepo, $mockValidator, $mockLogger, $csvFile) extends CsvIngester {
            private string $csvPath;
            public function __construct($repo, $validator, $logger, string $csvPath)
            {
                parent::__construct($repo, $validator, $logger, $csvPath);
                $this->csvPath = $csvPath;
            }
        };

        $ingester->ingest();
        unlink($csvFile);
    }

    public function testCsvIngesterSkipsInvalidProduct(): void {
        $mockRepo = $this->createMock(ProductRepositoryInterface::class);
        $mockValidator = $this->createMock(ValidationService::class);
        $mockLogger = $this->createMock(LoggerInterface::class);

        // Validation fails
        $mockValidator->method('validate')->willReturn(false);

        // Should not attempt to save the product
        $mockRepo->expects($this->never())->method('saveProduct');

        // Expect a warning to be logged
        $mockLogger->expects($this->once())
            ->method('warn')
            ->with($this->stringContains('Invalid product'));

        // Write a CSV with one row
        $csvFile = tempnam(sys_get_temp_dir(), 'csv');
        file_put_contents($csvFile, <<<CSV
gtin,language,title,picture,description,price,stock
1234567890123,en,Invalid Product,https://example.com/image.jpg,bad,0.00,0
CSV);

        $ingester = new CsvIngester($mockRepo, $mockValidator, $mockLogger, $csvFile);
        $ingester->ingest();

        unlink($csvFile);
    }

}
