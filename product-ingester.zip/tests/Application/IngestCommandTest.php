<?php

namespace Tests\Application;

use App\Application\Command\IngestCommand;
use App\Application\Ingester\CsvIngester;
use App\Domain\Service\ValidationService;
use App\Infrastructure\Persistence\MySQLProductRepository;
use PHPUnit\Framework\TestCase;
use App\Infrastructure\Logger\LoggerInterface;
use Symfony\Component\Console\Tester\CommandTester;

class IngestCommandTest extends TestCase {

    public function testCommandRunsAndShowsSuccessMessage(): void
    {
        $mockIngester = $this->createMock(CsvIngester::class);
        $mockLogger = $this->createMock(LoggerInterface::class);

        $mockIngester->expects($this->once())->method('ingest');

        $command = new IngestCommand($mockIngester, $mockLogger);

        $tester = new CommandTester($command);
        $exitCode = $tester->execute([]);

        $this->assertSame(0, $exitCode);
        $this->assertStringContainsString('Ingester completed successfully!', $tester->getDisplay());
    }


    public function testCommandFailsIfCsvFileIsMissing(): void {
        $mockLogger = $this->createMock(\App\Infrastructure\Logger\LoggerInterface::class);

        $mockLogger->expects($this->once())
            ->method('error')
            ->with($this->stringContains('CSV file not found'));

        // Real CsvIngester with fake path (this will throw inside ingest())
        $csvIngester = new CsvIngester(
            $this->createMock(MySQLProductRepository::class),
            $this->createMock(ValidationService::class),
            $mockLogger,
            '/nonexistent/path/feed.csv'
        );

        $command = new IngestCommand($csvIngester, $mockLogger);

        $tester = new CommandTester($command);
        $exitCode = $tester->execute([]);

        $this->assertSame(1, $exitCode);
        $this->assertStringContainsString('Ingester failed', $tester->getDisplay());
    }
}
