<?php

namespace Infrastructure\Persistence;

use App\Domain\Entity\Product;
use App\Infrastructure\Persistence\MySQLProductRepository;
use PHPUnit\Framework\TestCase;

class MySQLProductRepositoryTest extends TestCase {
    private \PDO $pdo;
    private MySQLProductRepository $repository;

    protected function setUp(): void {
        $this->pdo = new \PDO(
            'mysql:host=' . getenv('DB_HOST') . ';dbname=' . getenv('DB_NAME'),
            getenv('DB_USER'),
            getenv('DB_PASSWORD'),
            [\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION]
        );

        $this->assertSame('products_test_db', getenv('DB_NAME'));


        // Optional: Truncate table before each test
        $this->pdo->exec('DELETE FROM tblProduct');

        $this->repository = new MySQLProductRepository($this->pdo);
    }

    public function testSaveProductInsertsIntoDatabase(): void {
        $product = new Product(
            '9999999999999',
            'en',
            'Test Product',
            'https://example.com/image.jpg',
            'This is a test product.',
            19.99,
            10
        );

        $this->repository->saveProduct($product);

        $stmt = $this->pdo->prepare('SELECT * FROM tblProduct WHERE ProductGtin = :gtin');
        $stmt->execute([':gtin' => '9999999999999']);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        $this->assertNotEmpty($row);
        $this->assertEquals('Test Product', $row['ProductTitle']);
        $this->assertEquals(19.99, (float) $row['ProductPrice']);
    }

    public function testSaveProductUpdatesExistingRow(): void {
        $gtin = '9999999999999';

        $original = new Product(
            $gtin,
            'en',
            'Original Title',
            'https://example.com/original.jpg',
            'Original description.',
            9.99,
            5
        );

        $updated = new Product(
            $gtin,
            'en',
            'Updated Title',
            'https://example.com/updated.jpg',
            'Updated description.',
            12.50,
            20
        );

        // Save original product
        $this->repository->saveProduct($original);

        // Save updated product with same GTIN — should trigger UPDATE
        $this->repository->saveProduct($updated);

        // Fetch from DB and verify it's updated
        $stmt = $this->pdo->prepare('SELECT * FROM tblProduct WHERE ProductGtin = :gtin');
        $stmt->execute([':gtin' => $gtin]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        $this->assertNotEmpty($row);
        $this->assertEquals('Updated Title', $row['ProductTitle']);
        $this->assertEquals('https://example.com/updated.jpg', $row['ProductPictureURL']);
        $this->assertEquals(12.50, (float) $row['ProductPrice']);
        $this->assertEquals(20, (int) $row['ProductStock']);
    }

}
