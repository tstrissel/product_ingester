<?php

namespace Infrastructure\Persistence;

use App\Infrastructure\Persistence\MySQLLanguageRepository;
use PDO;
use PHPUnit\Framework\TestCase;

class MySQLLanguageRepositoryTest extends TestCase {
    private PDO $pdo;

    protected function setUp(): void {
        $this->pdo = new PDO(
            'mysql:host=' . getenv('DB_HOST') . ';dbname=' . getenv('DB_NAME'),
            getenv('DB_USER'),
            getenv('DB_PASSWORD'),
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }

    public function testLanguageExistsReturnsTrue(): void {
        $repo = new MySQLLanguageRepository($this->pdo);

        $this->assertTrue($repo->existsByCode('en'));
        $this->assertTrue($repo->existsByCode('de'));
    }

    public function testLanguageExistsReturnsFalse(): void {
        $repo = new MySQLLanguageRepository($this->pdo);

        $this->assertFalse($repo->existsByCode('jp'));
        $this->assertFalse($repo->existsByCode('xx'));
    }
}

