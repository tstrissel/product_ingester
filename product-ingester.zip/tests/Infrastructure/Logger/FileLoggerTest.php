<?php


namespace Tests\Infrastructure\Logger;

use App\Infrastructure\Logger\FileLogger;
use PHPUnit\Framework\TestCase;

/**
 *
 */
class FileLoggerTest extends TestCase {
    /**
     * @var string|false
     */
    private string $logFile;

    /**
     * @return void
     */
    protected function setUp(): void {
        $this->logFile = tempnam(sys_get_temp_dir(), 'log');
    }

    /**
     * @return void
     */
    protected function tearDown(): void {
        if (file_exists($this->logFile)) {
            unlink($this->logFile);
        }
    }

    /**
     * Tests that logging info works
     *
     * @return void
     */
    public function testLogsInfoMessage(): void {
        $logger = new FileLogger($this->logFile);
        $logger->info('This is an info message');

        $content = file_get_contents($this->logFile);
        $this->assertStringContainsString('INFO', $content);
        $this->assertStringContainsString('This is an info message', $content);
    }

    /**
     * Tests that logging warnings works
     * @return void
     */
    public function testLogsWarningMessage(): void {
        $logger = new FileLogger($this->logFile);
        $logger->warn('Ruh roh!');

        $content = file_get_contents($this->logFile);
        $this->assertStringContainsString('WARN', $content);
        $this->assertStringContainsString('Ruh roh', $content);
    }

    /**
     * Tests that logging errors works
     *
     * @return void
     */
    public function testLogsErrorMessage(): void {
        $logger = new FileLogger($this->logFile);
        $logger->error('Aww jeez Rick, this is bad.');

        $content = file_get_contents($this->logFile);
        $this->assertStringContainsString('ERROR', $content);
        $this->assertStringContainsString('Aww jeez Rick, this is bad.', $content);
    }

    /**
     * Creates a test log in a directory, then deletes it, so we can test log directory creation
     *
     * @return void
     */
    public function testLogsInfoMessageCreatesDirectory(): void {
        $logDir = sys_get_temp_dir() . '/logtest_' . uniqid();
        $logFile = $logDir . '/test.log';

        // Ensure clean state
        if (file_exists($logDir)) {
            unlink($logFile);
            rmdir($logDir);
        }

        // At this point, the directory does not exist
        $logger = new FileLogger($logFile);
        $logger->info('This message should trigger directory creation.');

        // Assertions
        $this->assertFileExists($logFile);
        $content = file_get_contents($logFile);
        $this->assertStringContainsString('INFO', $content);
        $this->assertStringContainsString('trigger directory creation', $content);

        // Cleanup
        unlink($logFile);
        rmdir($logDir);
    }

}
