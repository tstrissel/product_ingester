<?php


namespace Tests\Application\Kernel;

use App\Kernel;
use PHPUnit\Framework\TestCase;
use Symfony\Component\DependencyInjection\ContainerInterface;

class KernelBootTest extends TestCase
{
    public function testKernelBootsSuccessfully(): void
    {
        $kernel = new Kernel('test', true);
        $kernel->boot();

        $this->assertInstanceOf(ContainerInterface::class, $kernel->getContainer());
    }
}

