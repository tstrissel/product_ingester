<?php

namespace Tests\Domain\Service;

use App\Domain\Entity\Product;
use App\Domain\Repository\LanguageRepositoryInterface;
use App\Domain\Service\ValidationService;
use PHPUnit\Framework\TestCase;

class ValidationServiceTest extends TestCase {
    public function testValidProductPassesValidation(): void {
        $mockLangRepo = $this->createMock(LanguageRepositoryInterface::class);
        $mockLangRepo->method('existsByCode')->with('en')->willReturn(true);

        $service = new ValidationService($mockLangRepo);

        $product = new Product(
            '1234567890123',
            'en',
            'Valid Product',
            'https://example.com/image.jpg',
            'Great product',
            10.99,
            100
        );

        $this->assertTrue($service->validate($product));
    }

    public function testInvalidProductFailsValidation(): void {
        $mockLangRepo = $this->createMock(LanguageRepositoryInterface::class);
        $mockLangRepo->method('existsByCode')->willReturn(true); // allow language to pass

        $service = new ValidationService($mockLangRepo);

        $product = new Product(
            '',         // invalid gtin
            'en',
            '',         // missing title
            '',         // missing picture
            '',         // missing description
            0.0,        // possibly valid, depending on your logic
            -5          // negative stock?
        );

        $this->assertFalse($service->validate($product));
    }

    public function testFailsWhenLanguageCodeIsUnknown(): void {
        $mockLangRepo = $this->createMock(LanguageRepositoryInterface::class);
        $mockLangRepo->method('existsByCode')->with('xx')->willReturn(false);

        $service = new ValidationService($mockLangRepo);

        $product = new Product(
            '1234567890123',
            'xx', // not in picklist
            'Mystery Product',
            'https://example.com/image.jpg',
            'Strange product',
            20.00,
            10
        );

        $this->assertFalse($service->validate($product));
    }

    public function testFailsWhenPictureUrlIsInvalid(): void {
        $mockLangRepo = $this->createMock(LanguageRepositoryInterface::class);
        $mockLangRepo->method('existsByCode')->with('en')->willReturn(true);

        $validator = new ValidationService($mockLangRepo);

        $product = new Product(
            '1234567890123',
            'en',
            'Broken Image',
            'not-a-valid-url', // invalid URL
            'Some product',
            9.99,
            5
        );

        $this->assertFalse($validator->validate($product));
    }

    public function testFailsWhenPriceIsBelowZero(): void {
        $mockLangRepo = $this->createMock(LanguageRepositoryInterface::class);
        $mockLangRepo->method('existsByCode')->with('en')->willReturn(true);

        $validator = new ValidationService($mockLangRepo);

        $product = new Product(
            '1234567890123',
            'en',
            'Bad Pricing',
            'https://example.com/image.jpg',
            'Negative price product',
            -1.00, // invalid price
            10
        );

        $this->assertFalse($validator->validate($product));
    }

}
