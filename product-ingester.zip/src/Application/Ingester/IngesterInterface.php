<?php
namespace App\Application\Ingester;

interface IngesterInterface
{
    /**
     * Imports product data from a source
     */
    public function ingest(): void;
}
