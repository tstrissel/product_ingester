<?php
namespace App\Application\Ingester;

use App\Domain\Entity\Product;
use App\Domain\Repository\ProductRepositoryInterface;
use App\Domain\Service\ValidationService;
use App\Infrastructure\Logger\LoggerInterface;
use League\Csv\Exception;
use League\Csv\Reader;

class CsvIngester implements IngesterInterface
{
    public function __construct(
        private readonly ProductRepositoryInterface $productRepository,
        private readonly ValidationService $validationService,
        private readonly LoggerInterface $logger,
        private readonly string $csvFilePath
    ) {}

    /**
     * @throws Exception
     */
    public function ingest(): void
    {
        if (!file_exists($this->csvFilePath)) {
            throw new Exception('CSV file not found: ' . $this->csvFilePath);
        }

        $csv = Reader::createFromPath($this->csvFilePath, 'r');
        $csv->setHeaderOffset(0);

        foreach ($csv as $record) {
            $product = new Product(
                $record['gtin'],
                $record['language'],
                $record['title'],
                $record['picture'],
                $record['description'],
                (float) $record['price'],
                (int) $record['stock']
            );

            if (!$this->validationService->validate($product)) {
                $this->logger->warn("Invalid product: " . json_encode($record));
                continue;
            }

            $this->productRepository->saveProduct($product);
        }
    }
}
