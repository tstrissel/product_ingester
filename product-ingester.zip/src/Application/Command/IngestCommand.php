<?php

namespace App\Application\Command;

use App\Application\Ingester\IngesterInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use App\Infrastructure\Logger\LoggerInterface;

#[AsCommand(
    name: 'app:ingest',
    description: 'Ingests product data'
)]
class IngestCommand extends Command
{
    private IngesterInterface $ingester;
    private LoggerInterface $logger;

    public function __construct(IngesterInterface $ingester, LoggerInterface $logger)
    {
        parent::__construct();
        $this->ingester = $ingester;
        $this->logger = $logger;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        try {
            $this->ingester->ingest();
            $output->writeln('<info>Ingester completed successfully!</info>');
            return Command::SUCCESS;
        } catch (\Throwable $e) {
            $this->logger->error($e->getMessage());
            $output->writeln('<error>Ingester failed: ' . $e->getMessage() . '</error>');
            return Command::FAILURE;
        }
    }
}
