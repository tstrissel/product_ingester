<?php

namespace App\Domain\Entity;

class Product
{
    /**
     * @param string $gtin Global Trade Item Number
     * @param string $language codes found in tblplLanguage e.g. 'en', 'de'
     * @param string $title 'Fancy Pants'
     * @param string $picture 'www.google.com'
     * @param string $description 'These are the fanciest pants'
     * @param float $price '10.0'
     * @param int $stock '20'
     */
    public function __construct(
        public readonly string $gtin,
        public readonly string $language,
        public readonly string $title,
        public readonly string $picture,
        public readonly string $description,
        public readonly float $price,
        public readonly int $stock
    ) {}
    /**
     * @return string
     */
    public function getGtin(): string
    {
        return $this->gtin;
    }

    /**
     * @return string
     */
    public function getLanguage(): string
    {
        return $this->language;
    }

    /**
     * @return string
     */
    public function getTitle(): string
    {
        return $this->title;
    }

    /**
     * @return string
     */
    public function getPicture(): string
    {
        return $this->picture;
    }

    /**
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * @return float
     */
    public function getPrice(): float
    {
        return $this->price;
    }

    /**
     * @return int
     */
    public function getStock(): int
    {
        return $this->stock;
    }
}
