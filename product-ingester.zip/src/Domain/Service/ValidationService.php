<?php

namespace App\Domain\Service;

use App\Domain\Entity\Product;
use App\Domain\Repository\LanguageRepositoryInterface;

class ValidationService
{
    /**
     * @var LanguageRepositoryInterface
     */
    private LanguageRepositoryInterface $languageRepository;

    /**
     * @param LanguageRepositoryInterface $languageRepository
     */
    public function __construct(LanguageRepositoryInterface $languageRepository) {
        $this->languageRepository = $languageRepository;
    }

    /**
     * @param Product $product
     * @return bool
     */
    public function validate(Product $product): bool {
        if (empty($product->getGtin()) || empty($product->getTitle()) || empty($product->getDescription())) {
            return false;
        }

        if (!filter_var($product->getPicture(), FILTER_VALIDATE_URL)) {
            return false;
        }

        if ($product->getPrice() < 0 || $product->getStock() < 0) {
            return false;
        }

        if (!$this->languageRepository->existsByCode($product->getLanguage())) {
            return false;
        }

        return true;
    }
}

