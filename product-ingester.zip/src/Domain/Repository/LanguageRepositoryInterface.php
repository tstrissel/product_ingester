<?php
namespace App\Domain\Repository;

interface LanguageRepositoryInterface {
    /**
     * @param string $languageCode
     * @return bool
     */
    public function existsByCode(string $languageCode): bool;
}
