<?php
namespace App\Domain\Repository;

use App\Domain\Entity\Product;

interface ProductRepositoryInterface {
    /**
     * @param Product $product
     * @return void
     */
    public function saveProduct(Product $product): void;
}
