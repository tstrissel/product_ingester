<?php

namespace App;

use Symfony\Bundle\FrameworkBundle\FrameworkBundle;
use Symfony\Component\HttpKernel\Kernel as BaseKernel;
use Symfony\Component\DependencyInjection\Loader\Configurator\ContainerConfigurator;
use Symfony\Bundle\FrameworkBundle\Kernel\MicroKernelTrait;
use Symfony\Component\Routing\Loader\Configurator\RoutingConfigurator;

class Kernel extends BaseKernel {
    use MicroKernelTrait;

    public function registerBundles(): iterable {
        return [
            new FrameworkBundle(),
        ];
    }

    public function getProjectDir(): string {
        return \dirname(__DIR__);
    }

    protected function configureContainer(ContainerConfigurator $container): void {
        $container->import($this->getProjectDir() . '/config/packages/*.yaml');
        $container->import($this->getProjectDir() . '/config/services.yaml');
    }

    protected function configureRoutes(RoutingConfigurator $routes): void {
        // Not needed for CLI apps, but no error now
    }
}
