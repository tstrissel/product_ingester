<?php
namespace App\Infrastructure\Persistence;

use App\Domain\Entity\Product;
use App\Domain\Repository\ProductRepositoryInterface;
use PDO;

class MySQLProductRepository implements ProductRepositoryInterface {
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function saveProduct(Product $product): void {
        $stmt = $this->pdo->prepare("
            INSERT INTO tblProduct (ProductGtin, ProductLanguageID, ProductTitle, ProductPictureURL, ProductDescription, ProductPrice, ProductStock)
            SELECT 
                :gtin, 
                l.LanguageID, 
                :title, 
                :picture, 
                :description, 
                :price, 
                :stock
            FROM tblplLanguage l
            WHERE l.LanguageCode = :language
            ON DUPLICATE KEY UPDATE 
                ProductTitle = VALUES(ProductTitle), 
                ProductPictureURL = VALUES(ProductPictureURL), 
                ProductDescription = VALUES(ProductDescription), 
                ProductPrice = VALUES(ProductPrice), 
                ProductStock = VALUES(ProductStock);
        ");

        $stmt->execute([
            ':gtin' => $product->getGtin(),
            ':language' => $product->getLanguage(),
            ':title' => $product->getTitle(),
            ':picture' => $product->getPicture(),
            ':description' => $product->getDescription(),
            ':price' => $product->getPrice(),
            ':stock' => $product->getStock(),
        ]);
    }
}
