<?php
namespace App\Infrastructure\Persistence;

use App\Domain\Repository\LanguageRepositoryInterface;
use PDO;

class MySQLLanguageRepository implements LanguageRepositoryInterface {
    private PDO $pdo;
    private const CACHE_KEY_PREFIX = 'language_exists:';

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function existsByCode(string $languageCode): bool {
        // Query database if not in cache
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM tblplLanguage WHERE LanguageCode = :code");
        $stmt->execute([':code' => $languageCode]);
        return (bool) $stmt->fetchColumn();
    }
}
