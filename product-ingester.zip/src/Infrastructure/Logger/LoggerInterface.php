<?php

namespace App\Infrastructure\Logger;

interface LoggerInterface {
    public function log(string $message, string $level): void;

    public function info(string $message): void;

    public function error(string $message): void;

    public function warn(string $message): void;


}